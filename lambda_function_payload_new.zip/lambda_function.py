import simplejson as json
import boto3

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    table=dynamodb.Table('SiteCounter')
    try:
        
        table.update_item(
            Key={
                'websitestats': 'visitors',
        },
    UpdateExpression='SET quantity = if_not_exists(quantity, :initial) + :inc',      
    ExpressionAttributeValues={
        ':inc': 1,
        ':initial': 0,
        }
)

        response = table.get_item(
            Key={
                'websitestats': 'visitors',
            },
    ProjectionExpression='quantity'        
)

        print(response['Item'])

        return {
    'statusCode': 200,
    'headers': {'Content-Type': 'application/json',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'},
    'body': json.dumps(response['Item'])
}
    except:
        raise